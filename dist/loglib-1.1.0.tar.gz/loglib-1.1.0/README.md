# loglib

---

Simple logging library made by Logan Houston for YLCB
Should work out of the box
